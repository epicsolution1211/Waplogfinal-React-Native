import React, {Component} from 'react';
import OneSignal from 'react-native-onesignal';
import { config } from './configProvider';


   class NotificationProvider {
       notificationfunction(massege,action_json,playerid,title)
         {
           console.log('player_id',playerid)
           console.log('action_json',action_json)
           console.log('massege',massege[config.language])
           console.log('title',title[config.language])
           console.log(massege[config.language])
           console.log(title[config.language])
          let contents = {'en':massege[config.language]};
          let data = {'action_json':action_json};
          
          // Make sure to send an String Array of playerIds
          let playerIds = [playerid];
          var other = {
            headings:{en:title[config.language]},
            group: 10,
           priority: 10,
          };
          OneSignal.postNotification(contents,data, playerIds, other);
         }
         
    }

  export const notification = new NotificationProvider();
     